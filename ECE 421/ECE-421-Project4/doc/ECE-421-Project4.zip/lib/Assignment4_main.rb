require_relative 'menu.rb'

Menu.new.run
